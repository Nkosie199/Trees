import java.util.Scanner;
/**
 * Asks the user to input a sequence of integers, constructs a SimpleBST from them, and prints
 * it out.
 * 
 * @author Stephan Jamieson 
 * @version 25/2/2015
 */
public class BSTHarness {


    public static void main(String args[]) {
        System.out.print("Enter a comma separated list of numbers for tree one: ");
        Scanner scanner = new Scanner(System.in);
        scanner = new Scanner(scanner.nextLine()).useDelimiter("\\s*,\\s*");

        SimpleBST tree = new  SimpleBST();
        
        while (scanner.hasNextInt() ){
            tree.insert(scanner.nextInt());//
        }
        System.out.print("Enter a comma separated list of numbers for tree two: ");
        Scanner scanner2 = new Scanner(System.in);
        scanner2 = new Scanner(scanner2.nextLine()).useDelimiter("\\s*,\\s*");

        SimpleBST tree2 = new  SimpleBST();
        
        while (scanner2.hasNextInt() ){
            tree2.insert(scanner2.nextInt());//
        }
        System.out.println("Tree one:");
        SimpleBST.print(tree, new SimpleTreeWriterImpl(System.out));
        System.out.println("Tree two:");
        SimpleBST.print(tree2, new SimpleTreeWriterImpl(System.out));
    }
}
