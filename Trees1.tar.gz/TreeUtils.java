import java.util.ArrayList;
import java.util.List;
/**
 * Checks whether or not 2 trees are similar in structure
 * 
 * @author Nkosi Gumede 
 * @version 2/3/2015
 */
public class TreeUtils {
	
	static int size;
	static BinaryTreeNode treeone;
	static BinaryTreeNode treetwo;
    /*
     * Determine whether node is a place holder i.e. node==BinaryTreeNode.EMPTY_NODE
     */
    public static boolean isPlaceHolder(BinaryTreeNode node){
    	if (node==BinaryTreeNode.EMPTY_NODE)
    		return true;
    	else
    		return false;
  
    }
    
    /*
     * Obtain a list containing the root node of the given structure i.e. tNode itself.
     */
    public static List<BinaryTreeNode> levelZero(BinaryTreeNode tNode){
    	List<BinaryTreeNode> levelzero = new ArrayList<BinaryTreeNode>(); //Create list to store level zero's nodes
    	levelzero.add(tNode); //add root node to level zero's list
    	return levelzero;
    }
    
    /*
     *  Given a list of nodes, obtain the next level.
     *  If the tree structure is incomplete, BinaryTreeNode.EMPTY_NODE is inserted as a place holder for each missing node. 
     */
    public static List<BinaryTreeNode> nextLevel(List<BinaryTreeNode> level){
    	List<BinaryTreeNode> nextlevel = new ArrayList<BinaryTreeNode>(); //Create list to store next level's nodes
    	size = level.size(); //number of nodes in current level
    	//System.out.println(size);
    	for (int i=0;i<size;i++){
    		if (level.get(i).hasLeft()){ //if the node has an integer in its left node you get its value and place it in the next level's list
    			nextlevel.add(level.get(i).getLeft());	
    		}
    		if (!level.get(i).hasLeft()){
    			nextlevel.add(BinaryTreeNode.EMPTY_NODE);
    		}
    		if (level.get(i).hasRight()){ //if the node has an integer in its right node you get its value and place it in the next level's list
    			nextlevel.add(level.get(i).getRight());
    		}
    		if (!level.get(i).hasRight()){
    			nextlevel.add(BinaryTreeNode.EMPTY_NODE);
    		}
    		else{}
    	}
    	
    	return nextlevel;
    	
    }
    
    /*
     * Determine whether one tree node structure is similar (has the same structure) as another.
     */
    public static boolean similar(BinaryTreeNode treeStructOne, BinaryTreeNode treeStructTwo){
    	treeone = treeStructOne;
    	treetwo = treeStructTwo;
    	if (treeone.hasLeft() && treetwo.hasLeft()){
    		
    	}
    	return true;
    }
    
}
