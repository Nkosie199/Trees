/**
 * Checks where to print out the tree (either on the console or in a text file) and then prints it out
 * 
 * @author Nkosi Gumede 
 * @version 2/3/2015
 */
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.List;

public class SimpleTreeWriterImpl implements SimpleTreeWriter 
{
	static int largest; // holds largest integer for a given tree to calculate max number of characters
	static int l; // gives which line number we are in in the tree
	static int maxchar; // holds maximum number of characters for spacing and place-holder computation
	static int h; //holds height of a given tree for spacing computation
	static int spacebefore; //holds number spaces required to go before each node according to the given formula
	static int spacebetween; //holds number of spaces requires to go between each node according to the given formula
	//static int firstspace; //holds the product of maxchar and spacebefore
	static int secondspace; //holds the product of maxchar and spacebetween
	//public static BinaryTreeNode node; //holds the root node given from the BinaryTreeNode
	static int placeholder;
	static List<BinaryTreeNode> currentLevel;
	static List<BinaryTreeNode> levelNill;
	static int r=1; //for choosing which tree to print to file
	static int w=0;
	PrintStream out1;
	PrintWriter out2;
	
	/*public void output(String msg, PrintStream out1, PrintWriter out2) {        
	    out1.println(msg);
	    out2.println(msg);
	}*/
	public SimpleTreeWriterImpl(PrintStream output){ //receives variable called System.out
		if (r==1){
			try {
				out1 = new PrintStream((new FileOutputStream("T1.out")));
				//System.setOut(output);
				w=1;
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
		if (w==1){
			try {
				output = new PrintStream((new FileOutputStream("T2.out")));
				//System.setOut(output);
				r++;
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				r++;
			}
		}
		
	} 
	/*
	 * Set the PrintStream object to be used for output. An implementing class may wish to supplement this functionality with a constructor that achieves the the same effect.
	 */
	public void setDestination(PrintStream output){
		
	}
	/*
     * Print a textual representation of the given tree structure to the PrintStream object specified with setDestination.
     */	
    public void write(BinaryTreeNode tree){ //tree=root
    	largest = tree.getLargest();
    	maxchar = String.valueOf(largest).length();
    	h = tree.getHeight();
    	
    
    	for (l=0;l<1;l++){ //loop for printing root node's level
    		spacebefore = (int) ((Math.pow(2,h-l)-1)/2);
    		//firstspace = maxchar*spacebefore;
    		
        	//Print spacing before ...
    		for (int i=0;i<spacebefore;i++){
    			System.out.print(" ");
    		}      	
        	//Print root node ...
        	System.out.println(tree.getItem());
    	}
    	
    	
    	// FOR SUBSEQUENT LOOPS
    	levelNill = TreeUtils.levelZero(tree); //Holds root list for printing
    	currentLevel = TreeUtils.nextLevel(levelNill); //Method required to get next level's list for printing
    	//System.out.println(currentLevel.get(0).getItem());
    	int k = currentLevel.size();
    	//System.out.println(currentLevel.get(1).getItem());
    	
    	for (l=1;l<h;l++){ //loop for printing each and every other level
    		spacebefore = (int) ((Math.pow(2,h-l)-1)/2);
    		//Print spacing before ...
    		for (int i=0;i<spacebefore;i++){
    			System.out.print(" ");
    		}
    		
    		for (int j=0;j<k;j++){
        		//System.out.print(currentLevel.get(j).getItem());
        		k = currentLevel.size();    		
        		//Print level's node and placeholder ...
    			int nodelength = String.valueOf(currentLevel.get(j).getItem()).length();
        		placeholder = maxchar-nodelength;
    			try{		
            		if (placeholder==0){ //ie no need for a placeholder
            			if (!currentLevel.get(j).getItem().equals(null)){
            				System.out.print(currentLevel.get(j).getItem());
            			}         			
            		}
            		else{
            			if (!currentLevel.get(j).getItem().equals(null)){
            				System.out.print(currentLevel.get(j).getItem());
            			}
            			for (int i=placeholder;i>0;i--){
            				System.out.print(" ");
            			}
            		}
            		
            		spacebetween = (int) (Math.pow(2,h-l)-1);
            		//Print spacing between ...
            		for (int i=0;i<spacebetween;i++){
            			System.out.print(" ");
            		}
    			}
    			catch (Exception e){ //in the case of null
    				for (int i=placeholder;i>0;i--){
        				System.out.print(" ");
        			}
    				//Print spacing between ...
            		for (int i=0;i<spacebetween;i++){
            			System.out.print(" ");
            		}
    			}
        		
        		
    		}
    		System.out.println("");
    		levelNill=currentLevel;
    		currentLevel = TreeUtils.nextLevel(levelNill); //Method required to get next level's list for printing
    	} 	 	
    }
}
