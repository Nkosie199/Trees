import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;
/**
 * Write a description of class BinaryTreeNodePrintStream here.
 * 
 * @author Nkosie Gumede 
 * @version 15/3/2015
 */
public class SimpleTreeWriterImpl implements SimpleTreeWriter {
	private PrintStream stream;

	public SimpleTreeWriterImpl(PrintStream output) {
	    this.setDestination(output);
	}

	public void setDestination(PrintStream output) {
	    this.stream=output;
	}
	
	public void write(AVLTreeNode node) {
		stream.println(node);
		//stream.println("Executing(3: SimpleTreeWriterImpl)...");
	    if (node == null) {
	        stream.println("");
	    } else {
	        List<AVLTreeNode> level = TreeUtils.levelZero(node);
	        //stream.println("levelzero done!");
	        final int labelSize = node.getLargest();

	        for (int levelNum = 0; levelNum < node.getHeight(); levelNum++) {
	            final int nodeSpacing = powerOf2(node.getHeight() - levelNum) - 1;
	            writeLevel(nodeSpacing, labelSize, level);
	            level = TreeUtils.nextLevel(level);
	            //stream.println("writeLevelCalled!");
	        }
	    }
	}

	private void writeLevel(int nodeSpacing, int labelSize, List<AVLTreeNode> level) {
		//stream.println("in writelevel now!...");
	    final String leadingSpace = makeSpacing((nodeSpacing / 2) * labelSize);
	    final String interNodeSpace = makeSpacing(nodeSpacing * labelSize);

	    Iterator<AVLTreeNode> iterator = level.iterator();
	    assert (iterator.hasNext());

	    stream.print(leadingSpace);
	    writeNode(iterator.next(), labelSize);

	    while (iterator.hasNext()) {
	        stream.print(interNodeSpace);
	        writeNode(iterator.next(), labelSize);
	    }
	    //stream.print("end of line!");
	    stream.println();
	}

	private void writeNode(AVLTreeNode node, int labelSize) {
		//stream.println("just about to write a node!");
	    final String blankNode = makeSpacing(labelSize);
	    if (TreeUtils.isPlaceHolder(node)) {
	        stream.printf(blankNode);
	    } else {
	        stream.printf("%" + labelSize + "s", node.toString());
	    }
	}

	private static int powerOf2(int power) {
	    if (power == 0) {
	        return 1;
	    } else {
	        return 2 * powerOf2(power - 1);
	    }
	}

	private static String makeSpacing(int size) {
	    StringBuilder builder = new StringBuilder(size);
	    while (size > 0) {
	        builder.append(' ');
	        size--;
	    }
	    return builder.toString();
	}
}
