import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
/**
 * Utility procedures for binary tree structures.
 * 
 * @author Stephan Jamieson
 * @version 25/2/2015
 */
public class TreeUtils {
	    
    /**
     * Obtain the height value of the given node.
     * @return 0 if <code>node==null</code>, otherwise <code>node.getHeight()</code>.
     */
    public static int height(AVLTreeNode node) {
        if (node==null) {
            return 0;
        }
        else {
            return node.getHeight();
        }
    }

    /** 
     * Determine whether the given tree structure contains the given key.
     */
    public static boolean contains(AVLTreeNode node, Integer key) {
        // Your code here.		
    	if (key.equals(node.getKey())) { return true; } //in the case of key being exactly the key node  
    	//System.out.println(key);
    	//System.out.println(node.getKey());
    	if (key<node.getKey()) { //if key value less than the node value
    		if (node.hasLeft()) {
    			if (key.equals(node.getLeft())) {
    				return true;
    			}
    			else {
    				return contains(node.getLeft(), key);
    			}
    		}
    		else { return false; }
    	}    
    	else { //if key value greater than the node value
    		if (node.hasRight()) {
    			if (key.equals(node.getRight())) {
    				return true;
    			}
    			else {
    				return contains(node.getRight(), key);
    			}
    		}
    		else { return false; }
    	} 	
    } 

    /**
     * Recursive implementation of insert on an AVLTreeNode structure.
     */
    public static AVLTreeNode insert(AVLTreeNode node, Integer key) {
        // Your code here
    	if (node==null){
    		node = new AVLTreeNode(key); //in the case of first insertion
    	} 
    	else if (key<node.getKey()) { //if inserted value less than the key node
            if (node.hasLeft()) { //we check if left branch of the key node is already has an integer
                return insert(node.getLeft(), key); //if so, recursively call insert function for next operation 
            }
            else { //left branch of key node is null
                node.setLeft(new AVLTreeNode(key)); //this method creates a new subtree on the left leaf
                //return insert(node.getLeft(), key);
            }
        }
    	else { //if inserted value is greater than the key node
            if (node.hasRight()) { //we check if right branch of the key node is already has an integer
                return insert(node.getRight(), key);
            }
            else {
                node.setRight(new AVLTreeNode(key)); //this method creates a new subtree in the right leaf
                //return insert(node.getRight(), key);
            }
        }
    	
    	System.out.print("new tree height ");
    	//node.setHeight(node.getHeight());
    	System.out.println(node.getHeight());
    	return rotationRequired(node);
    }
    
    public static AVLTreeNode rotationRequired(AVLTreeNode k){
    	if (k.getBalanceFactor()<-1){ //if the tree is right heavy
    		if (k.getRight().getBalanceFactor()>1){ //if tree's right subtree is left heavy
    			return doubleRotateWithLeftChild(k);
    		}
    		else{
    			return rotateWithLeftChild(k);
    		}
    	}
    	else if (k.getBalanceFactor()>1){ //if the tree is left heavy
    		if (k.getLeft().getBalanceFactor()<-1){ //if tree's left subtree is right heavy
    	        return doubleRotateWithRightChild(k);
    		}
    		else{
    			return rotateWithRightChild(k);
    		}
    	}
    	else{
    		return k;
    	}
    	
    }
   	
    /**
     * Rotate binary tree node with left child.
     * This is a single rotation for case 1.
     */
    
    public static AVLTreeNode rotateWithLeftChild( AVLTreeNode k2 )
    {
        // Your code here
    	AVLTreeNode k1 = k2.getLeft();
        k2.setLeft(k1.getRight());
        k1.setRight(k2);
        return k1;
    }

    /**
     * Rotate binary tree node with right child.
     * This is a single rotation for case 4.
     */
    public static AVLTreeNode rotateWithRightChild( AVLTreeNode k1 )
    {
        // Your code here
    	AVLTreeNode k2 = k1.getRight(); //BinaryNode k2 = k1.right;
        k1.setRight(k2.getLeft()); //k1.right = k2.left;
        k2.setLeft(k1); //k2.left = k1;
        return k2;
    }

    /**
     * Double rotate binary tree node: first rotate k3's left child
     * with its right child; then rotate node k3 with the new left child.
     * This is a double rotation for case 2.
     */
    public static AVLTreeNode doubleRotateWithLeftChild( AVLTreeNode k3 )
    {
        // Your code here.
    	k3.setLeft(rotateWithRightChild( k3.getLeft() ));
        return rotateWithLeftChild( k3 );
    }

    /**
     * Double rotate binary tree node: first rotate k1's right child
     * with its left child; then rotate node k1 with the new right child.
     * This is a double rotation for case 3.
     */
    public static AVLTreeNode doubleRotateWithRightChild( AVLTreeNode k1 )
    {
        // Your code here.
    	k1.setRight(rotateWithLeftChild( k1.getRight() ));
        return rotateWithRightChild( k1 );
    }

    
    /**
     * Obtain a list containing the root node of the given structure i.e. tNode itself.
     */
    public static List<AVLTreeNode> levelZero(AVLTreeNode tNode) {
        List<AVLTreeNode> level = new ArrayList<AVLTreeNode>();
        level.add(tNode);
        return level;
    }
    
    
    /**
     * Given a list of nodes, obtain the next level. 
     * 
     * <p>
     * If the tree structure is incomplete, <code>AVLTreeNode.EMPTY_NODE</code> is inserted as a place holder for each
     * missing node.
     * </p>
     */
    public static List<AVLTreeNode> nextLevel(List<AVLTreeNode> level) {
        List<AVLTreeNode> nextLevel = new ArrayList<AVLTreeNode>(); 
        
        for (AVLTreeNode node : level) {
            nextLevel.add(node.hasLeft() ? node.getLeft() : AVLTreeNode.EMPTY_NODE); 
            nextLevel.add(node.hasRight() ? node.getRight() : AVLTreeNode.EMPTY_NODE);
        }
        return nextLevel;
    }
    
    /**
     * Determine whether node is a place holder i.e. <code>node==AVLTreeNode.EMPTY_NODE</code>
     */
    public static boolean isPlaceHolder(AVLTreeNode node) {
        return node==AVLTreeNode.EMPTY_NODE;
    }
    
}
