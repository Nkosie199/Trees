package tasktwo;
import java.io.PrintStream;
/**
 * Implementation of an AVL Tree
 * 
 * @author Stephan Jamieson
 * @version 3/3/2015
 */
public class AVLTree {

    private static AVLTreeNode root;

    /**
     * Create an empty AVL tree
     */
    public AVLTree() {
        root = null;
    }
    
    /**
     * Insert the given key into the tree.
     */
    public void insert(String key) {
        root = TreeUtils.insert(root, key);
    }

    /**
     * Use the given PrintStream object to output a textual representation of this tree.
     */
    public void print(PrintStream printStream) {
        SimpleTreeWriter writer = new SimpleTreeWriterImpl(printStream);
        rootHeight();
        //System.out.print("Height from AVLTree.java: ");
        //System.out.print(root.getHeight());
        //System.out.print(" root node is now: ");
        //System.out.println(root.getKey());
        //System.out.println("Executing(2: AVLTree.java)...");
        writer.write(this.root);
    }
    /*
     * Method to adjust root height over each iteration
     */
    public static void rootHeight(){
    	try{
    		if (root.hasLeft() && root.hasRight()) {
                root.setHeight(Math.max(root.getLeft().getHeight(), root.getRight().getHeight())+1);
                //System.out.println("root height incremented");
            }
            else if (root.hasLeft()) {
                root.setHeight(root.getLeft().getHeight()+1);
                //System.out.println("root height incremented");
            }
            else if (root.hasRight()) {
                root.setHeight(root.getRight().getHeight()+1);
                //System.out.println("root height incremented");
            }
            else {
                root.setHeight(1);
            }
    	}
    	catch (Exception e){
    		
    	}
    }
    /**
     * Determine whether the tree contains the given key.
     */
    public boolean contains(String key) {
        if (root==null) {
            return false;
        }
        else {
            return TreeUtils.contains(root, key);
        }
    }
}
