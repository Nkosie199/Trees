package tasktwo;
import java.util.HashMap;
import java.util.Map;
/**
 * Implements a node suitable for building AVL tree structures.
 * 
 * @author Stephan Jamieson
 * @version 3/3/2015
 */
public class AVLTreeNode {
	private Map<String, Integer> assign = new HashMap<String, Integer>();
	private Integer resp;
    private String key;
    private int height;
    
    private AVLTreeNode left;
    private AVLTreeNode right;
    
    public final static AVLTreeNode EMPTY_NODE = new AVLTreeNode();
    
    private AVLTreeNode() { this.key=null; this.height=-1; this.left=null; this.right=null; }
    
    
    /**
     * Create an AVLTreeNode that contains the given key
     */
    public AVLTreeNode(String key) { this(null, key, null); }
    
    private AVLTreeNode(AVLTreeNode left, String key, AVLTreeNode right) {
        assert(key!=null);
        this.left=left;
        this.right=right;
        this.key=key;
        this.height=1;
    }
    
    /* Low level structural operations */  
    /**
     * Determine whether this node has a left branch.
     */
    public boolean hasLeft() { return left!=null; }
    /**
     * Determine whether this node has a right branch.
     */
    public boolean hasRight() { return right!=null; }
    
    /** 
     * Determine whether this node has a key.
     */
    public boolean hasKey() { return key!=null; }
        
    /**
     * Obtain the key stored in this node.
     */
    public String getKey() { return key; }
    
    /**
     * Obtain the height value stored at this node. (Requirs that ka
     */
    public int getHeight() {
        return this.height;
    }
    
    /**
     * Obtain the balance factor for this node.
     */
    public int getBalanceFactor() { 
        int left = (this.hasLeft() ? this.getLeft().getHeight() : 0);
        int right = (this.hasRight() ? this.getRight().getHeight() : 0);
        return left-right;
    }

        
        /**
     * Obtain this node's left branch. Requires that <code>this.hasLeft()</code>.
     */
    public AVLTreeNode getLeft() { 
        return this.left; 
    }
    /**
     * Obtain this node's right branch. Requires that <code>this.hasRight()</code>.
     */
    public AVLTreeNode getRight() { 
        return this.right; 
    }
    
    /**
     * Set the height stored in this node.
     */
    public void setHeight(int height) { 
        assert(this!=EMPTY_NODE);
        this.height=height; 
    }
    
    /**
     * Set this node's left branch.
     */
    public void setLeft(AVLTreeNode tree) {
        assert(this!=EMPTY_NODE);
        this.left = tree;
    }
    
    /**
     * Set this node's right branch.
     */
    public void setRight(AVLTreeNode tree) {
        assert(this!=EMPTY_NODE);
        this.right = tree;
    }
    
    /**
     * Obtain the longest node label for nodes stored in this tree structure.
     */
    public Integer getLargest() {
        Integer largest = this.toString().length();
        if (this.hasLeft()) 
            largest = Math.max(largest, this.getLeft().getLargest());
        if (this.hasRight()) 
            largest = Math.max(largest, this.getRight().getLargest());
        
        return largest;
    }

            
    /**
     * Obtain a String representation of this node.
     */
    public String toString() {
    	String x = String.valueOf(this.getKey().charAt(0));
        return this.represents(x)+"("+this.getBalanceFactor()+")"+"("+this.getKey().toString()+")";
    }
    
    /**
     * Get a numerical version assignment of the given character
     */
    public Integer represents (String ch){
    	assign.put("a",1);
    	assign.put("b",2);
    	assign.put("c",3);
    	assign.put("d",4);
    	assign.put("e",5);
    	assign.put("f",6);
    	assign.put("g",7);
    	assign.put("h",8);
    	assign.put("i",9);
    	assign.put("j",10);
    	assign.put("k",11);
    	assign.put("l",12);
    	assign.put("m",13);
    	assign.put("n",14);
    	assign.put("o",15);
    	assign.put("p",16);
    	assign.put("q",17);
    	assign.put("r",18);
    	assign.put("s",19);
    	assign.put("t",20);
    	assign.put("u",21);
    	assign.put("v",22);
    	assign.put("w",23);
    	assign.put("x",24);
    	assign.put("y",25);
    	assign.put("z",26);
    	if (assign.containsKey(ch)){
    		resp = assign.get(ch);
    	}
    	return resp;
    }

}
